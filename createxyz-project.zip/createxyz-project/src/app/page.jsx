"use client";
import React from "react";

function MainComponent() {
  const [prompt, setPrompt] = useState("");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState("ar");
  const languages = [
    { code: "ar", name: "العربية" },
    { code: "en", name: "English" },
    { code: "fr", name: "Français" },
    { code: "es", name: "Español" },
    { code: "tr", name: "Türkçe" },
  ];
  const socialLinks = [
    {
      name: "Facebook",
      icon: "fab fa-facebook",
      url: "https://facebook.com/yourpage",
    },
    {
      name: "Instagram",
      icon: "fab fa-instagram",
      url: "https://instagram.com/yourpage",
    },
    { name: "Telegram", icon: "fab fa-telegram", url: "https://t.me/yourpage" },
    {
      name: "TikTok",
      icon: "fab fa-tiktok",
      url: "https://tiktok.com/@yourpage",
    },
  ];

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  useEffect(() => {
    const translatePage = async () => {
      if (currentLanguage === "ar") return;

      try {
        const elementsToTranslate =
          document.querySelectorAll("[data-translate]");
        for (let element of elementsToTranslate) {
          const originalText =
            element.getAttribute("data-original-text") || element.textContent;
          element.setAttribute("data-original-text", originalText);

          const response = await fetch(
            "/integrations/google-translate/language/translate/v2",
            {
              method: "POST",
              body: new URLSearchParams({
                q: originalText,
                target: currentLanguage,
              }),
            }
          );
          if (!response.ok) {
            throw new Error("Translation failed");
          }
          const data = await response.json();
          element.textContent = data.data.translations[0].translatedText;
        }
      } catch (error) {
        console.error("خطأ في الترجمة:", error);
      }
    };

    translatePage();
  }, [currentLanguage]);

  const quickSuggestions = [
    "منظر طبيعي جميل لغروب الشمس",
    "قطة لطيفة تلعب بكرة صوف",
    "مدينة مستقبلية في الليل",
  ];
  const validateInput = (value) => {
    if (value.length < 3) {
      setError("الرجاء إدخال وصف أطول");
    } else {
      setError("");
    }
  };
  const handlePromptChange = (e) => {
    const value = e.target.value;
    setPrompt(value);
    validateInput(value);
  };
  const generateImage = async () => {
    if (prompt.length < 3) {
      setError("الرجاء إدخال وصف أطول");
      return;
    }

    setLoading(true);
    setError("");
    try {
      const response = await fetch(
        `/integrations/dall-e-3/?prompt=${encodeURIComponent(prompt)}`
      );
      if (!response.ok) {
        throw new Error(`حدث خطأ: ${response.status}`);
      }
      const data = await response.json();
      setImage(data.data[0]);
    } catch (err) {
      setError("عذراً، حدث خطأ أثناء توليد الصورة. الرجاء المحاولة مرة أخرى.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const resetForm = () => {
    setPrompt("");
    setImage("");
    setError("");
  };
  const downloadImage = async () => {
    try {
      const response = await fetch(image);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `generated-image-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("خطأ في تحميل الصورة:", error);
      setError("عذراً، حدث خطأ أثناء تحميل الصورة. الرجاء المحاولة مرة أخرى.");
    }
  };

  if (isLoading) {
    return (
      <div
        className={`min-h-screen ${
          isDarkMode ? "bg-[#121212]" : "bg-white"
        } flex items-center justify-center`}
      >
        <div className="text-center">
          <div className="relative w-24 h-24 mx-auto mb-8">
            <div
              className={`absolute top-0 left-0 w-full h-full border-4 ${
                isDarkMode ? "border-[#333333]" : "border-gray-200"
              } rounded-full animate-ping`}
            ></div>
            <div
              className={`absolute top-0 left-0 w-full h-full border-4 ${
                isDarkMode
                  ? "border-t-white border-[#333333]"
                  : "border-t-black border-gray-200"
              } rounded-full animate-spin`}
            ></div>
          </div>
          <h2
            className={`${
              isDarkMode ? "text-white" : "text-black"
            } text-2xl font-bold animate-pulse`}
          >
            جاري تحميل مولد الصور الذكي
          </h2>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen ${
        isDarkMode ? "bg-[#121212] text-white" : "bg-white text-black"
      } p-8 flex flex-col items-center`}
    >
      <div className="fixed top-4 left-4 z-10">
        <button
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="p-3 rounded-full transition-colors"
          style={{
            backgroundColor: isDarkMode ? "#333333" : "#f0f0f0",
            color: isDarkMode ? "white" : "black",
          }}
          title={isDarkMode ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"}
        >
          <i className={`fas ${isDarkMode ? "fa-sun" : "fa-moon"}`}></i>
        </button>
      </div>
      <h1
        className="text-5xl md:text-6xl font-bold mb-8 font-roboto text-center"
        data-translate
      >
        مولد الصور الذكي
      </h1>

      <div className="fixed top-4 right-4 z-20">
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className={`p-3 rounded-full transition-colors ${
            isDarkMode
              ? "bg-[#333333] hover:bg-[#444444] text-white"
              : "bg-gray-200 hover:bg-gray-300 text-black"
          } z-20 ${isMenuOpen ? "opacity-0" : "opacity-100"}`}
        >
          <i className="fas fa-bars"></i>
        </button>

        <div
          className={`fixed top-0 right-0 h-full w-full md:w-1/2 lg:w-1/3 transform transition-all duration-300 ease-in-out ${
            isDarkMode ? "bg-[#1E1E1E]" : "bg-white"
          } ${isMenuOpen ? "translate-x-0" : "translate-x-full"}`}
          style={{ maxWidth: "400px" }}
        >
          <button
            onClick={() => setIsMenuOpen(false)}
            className={`absolute top-4 right-4 p-3 rounded-full transition-colors ${
              isDarkMode
                ? "bg-[#333333] hover:bg-[#444444] text-white"
                : "bg-gray-200 hover:bg-gray-300 text-black"
            }`}
          >
            <i className="fas fa-times text-xl"></i>
          </button>

          <div className="h-full overflow-y-auto p-6 pt-20">
            <div className="mb-6">
              <h3
                className={`text-xl font-bold mb-4 ${
                  isDarkMode ? "text-white" : "text-black"
                }`}
                data-translate
              >
                اختر اللغة
              </h3>
              <div className="space-y-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setCurrentLanguage(lang.code)}
                    className={`w-full text-right py-3 px-4 rounded ${
                      currentLanguage === lang.code
                        ? isDarkMode
                          ? "bg-[#333333]"
                          : "bg-gray-200"
                        : "hover:bg-opacity-50"
                    } transition-colors flex items-center justify-between`}
                  >
                    <span>{lang.name}</span>
                    {currentLanguage === lang.code && (
                      <i className="fas fa-check text-green-500"></i>
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h3
                className={`text-xl font-bold mb-4 ${
                  isDarkMode ? "text-white" : "text-black"
                }`}
                data-translate
              >
                تواصل معنا
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`p-3 rounded-lg ${
                      isDarkMode
                        ? "bg-[#333333] hover:bg-[#444444] text-white"
                        : "bg-gray-200 hover:bg-gray-300 text-black"
                    } flex items-center justify-center gap-2 transition-colors`}
                  >
                    <i className={social.icon}></i>
                    <span>{social.name}</span>
                  </a>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: "مولد الصور الذكي",
                    text: "جرب مولد الصور الذكي الآن!",
                    url: window.location.href,
                  });
                }
              }}
              className={`w-full py-3 px-4 rounded ${
                isDarkMode
                  ? "bg-[#333333] hover:bg-[#444444] text-white"
                  : "bg-gray-200 hover:bg-gray-300 text-black"
              } flex items-center justify-center gap-2 transition-colors`}
              data-translate
            >
              <i className="fas fa-share-alt"></i>
              مشاركة التطبيق
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-[-1]"
            onClick={() => setIsMenuOpen(false)}
          ></div>
        )}
      </div>

      <div className="w-full max-w-2xl">
        <div className="flex flex-wrap gap-2 mb-4">
          {quickSuggestions.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => setPrompt(suggestion)}
              className={`px-3 py-1 ${
                isDarkMode
                  ? "bg-[#2A2A2A] hover:bg-[#3A3A3A]"
                  : "bg-gray-200 hover:bg-gray-300"
              } rounded-full text-sm transition-colors`}
              data-translate
            >
              {suggestion}
            </button>
          ))}
        </div>
        <div className="relative">
          <textarea
            value={prompt}
            onChange={handlePromptChange}
            placeholder="صف الصورة التي تريد إنشاءها..."
            className={`w-full h-32 p-4 rounded-lg ${
              isDarkMode
                ? "bg-[#1E1E1E] text-white border-gray-700"
                : "bg-gray-100 text-black border-gray-300"
            } border focus:border-gray-500 focus:outline-none resize-none font-crimson-text text-lg`}
            dir="rtl"
            data-translate
          />
          {prompt && (
            <button
              onClick={resetForm}
              className={`absolute top-2 left-2 ${
                isDarkMode
                  ? "text-gray-400 hover:text-white"
                  : "text-gray-600 hover:text-black"
              }`}
            >
              <i className="fas fa-times"></i>
            </button>
          )}
        </div>
        <button
          onClick={generateImage}
          disabled={loading || prompt.length < 3}
          className={`w-full mt-4 py-4 px-6 ${
            isDarkMode
              ? "bg-[#333333] hover:bg-[#444444] text-white"
              : "bg-gray-200 hover:bg-gray-300 text-black"
          } transition-colors rounded-lg font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed`}
          data-translate
        >
          {loading ? (
            <div className="flex items-center justify-center gap-2">
              <i className="fas fa-spinner fa-spin"></i>
              <span data-translate>جاري التوليد...</span>
            </div>
          ) : (
            "توليد الصورة"
          )}
        </button>

        {error && (
          <div className="mt-4 text-red-500 text-center font-crimson-text">
            {error}
          </div>
        )}

        {loading && !image && (
          <div
            className={`mt-8 w-full h-64 ${
              isDarkMode ? "bg-[#1E1E1E]" : "bg-gray-100"
            } rounded-lg animate-pulse flex items-center justify-center`}
          >
            <span className={isDarkMode ? "text-gray-400" : "text-gray-600"}>
              جاري تحضير صورتك...
            </span>
          </div>
        )}

        {image && (
          <div className="mt-8">
            <div className="relative rounded-lg overflow-hidden shadow-lg">
              <img src={image} alt="الصورة المولدة" className="w-full" />
              <div className="absolute top-2 right-2 flex gap-2">
                <button
                  onClick={downloadImage}
                  className={`${
                    isDarkMode
                      ? "bg-[#333333] hover:bg-[#444444]"
                      : "bg-gray-200 hover:bg-gray-300 text-black"
                  } p-2 rounded-full transition-colors`}
                  title="تحميل الصورة"
                >
                  <i className="fas fa-download"></i>
                </button>
                <button
                  onClick={() => {
                    if (navigator.share) {
                      navigator.share({
                        title: "صورة مولدة بواسطة الذكاء الاصطناعي",
                        text: prompt,
                        url: image,
                      });
                    }
                  }}
                  className={`${
                    isDarkMode
                      ? "bg-[#333333] hover:bg-[#444444]"
                      : "bg-gray-200 hover:bg-gray-300 text-black"
                  } p-2 rounded-full transition-colors`}
                  title="مشاركة الصورة"
                >
                  <i className="fas fa-share-alt"></i>
                </button>
              </div>
            </div>

            <div className="mt-4 flex gap-3">
              <button
                onClick={() => generateImage()}
                className={`flex-1 py-3 px-4 ${
                  isDarkMode
                    ? "bg-[#333333] hover:bg-[#444444] text-white"
                    : "bg-gray-200 hover:bg-gray-300 text-black"
                } transition-colors rounded-lg font-bold text-sm flex items-center justify-center gap-2`}
              >
                <i className="fas fa-random"></i>
                توليد نسخة مختلفة
              </button>
              <button
                onClick={resetForm}
                className={`flex-1 py-3 px-4 ${
                  isDarkMode
                    ? "bg-[#333333] hover:bg-[#444444] text-white"
                    : "bg-gray-200 hover:bg-gray-300 text-black"
                } transition-colors rounded-lg font-bold text-sm flex items-center justify-center gap-2`}
              >
                <i className="fas fa-plus"></i>
                إنشاء صورة جديدة
              </button>
            </div>
          </div>
        )}
      </div>

      <div
        className={`mt-8 text-center ${
          isDarkMode ? "text-gray-400" : "text-gray-600"
        }`}
      >
        <p className="text-sm">
          Made with ❤️ by{" "}
          <a
            href="https://github.com/g-m0h1"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
          >
            g.m0h1
          </a>
        </p>
      </div>
    </div>
  );
}

export default MainComponent;